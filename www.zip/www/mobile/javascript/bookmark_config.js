﻿var ols = [

{
    caption: "فهرس السور\t",
    page: "2",
    url: "",
    level: "0",
    children: [{
    caption: "الفاتحة",
    page: "2",
    url: "",
    level: "0",
    children: []
}, {
    caption: "البقرة",
    page: "3",
    url: "",
    level: "0",
    children: []
}, {
    caption: "آل عمران",
    page: "42",
    url: "",
    level: "0",
    children: []
}, {
    caption: "النساء",
    page: "63",
    url: "",
    level: "0",
    children: []
}, {
    caption: " المائدة",
    page: "87",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الأنعام",
    page: "105",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الأعراف",
    page: "123",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الأنفال",
    page: "143",
    url: "",
    level: "0",
    children: []
}, {
    caption: " التوبة",
    page: "151",
    url: "",
    level: "0",
    children: []
}, {
    caption: "يونس",
    page: "168",
    url: "",
    level: "0",
    children: []
}, {
    caption: "هود",
    page: "179",
    url: "",
    level: "0",
    children: []
}, {
    caption: "يوسف",
    page: "191",
    url: "",
    level: "0",
    children: []
}, {
    caption: " الرعد",
    page: "201",
    url: "",
    level: "0",
    children: []
}, {
    caption: "إبراهيم",
    page: "207",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الحجر",
    page: "212",
    url: "",
    level: "0",
    children: []
}, {
    caption: " النحل",
    page: "216",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الإسراء",
    page: "228",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الكهف",
    page: "237",
    url: "",
    level: "0",
    children: []
}, {
    caption: "مريم",
    page: "246",
    url: "",
    level: "0",
    children: []
}, {
    caption: "طه",
    page: "252",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الأنبياء",
    page: "260",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الحج",
    page: "268",
    url: "",
    level: "0",
    children: []
}, {
    caption: "المؤمنون",
    page: "276",
    url: "",
    level: "0",
    children: []
}, {
    caption: " النور",
    page: "282",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الفرقان",
    page: "290",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الشعراء",
    page: "296",
    url: "",
    level: "0",
    children: []
}, {
    caption: "النمل",
    page: "303",
    url: "",
    level: "0",
    children: []
}, {
    caption: "القصص",
    page: "311",
    url: "",
    level: "0",
    children: []
}, {
    caption: "العنكبوت",
    page: "319",
    url: "",
    level: "0",
    children: []
}, {
    caption: " الروم",
    page: "325",
    url: "",
    level: "0",
    children: []
}, {
    caption: "لقمان",
    page: "330",
    url: "",
    level: "0",
    children: []
}, {
    caption: "السجدة",
    page: "333",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الأحزاب",
    page: "336",
    url: "",
    level: "0",
    children: []
}, {
    caption: "سبأ",
    page: "345",
    url: "",
    level: "0",
    children: []
}, {
    caption: "فاطر",
    page: "350",
    url: "",
    level: "0",
    children: []
}, {
    caption: "يس",
    page: "354",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الصافات",
    page: "359",
    url: "",
    level: "0",
    children: []
}, {
    caption: "ص",
    page: "365",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الزمر",
    page: "369",
    url: "",
    level: "0",
    children: []
}, {
    caption: "غافر",
    page: "376",
    url: "",
    level: "0",
    children: []
}, {
    caption: "فصلت",
    page: "383",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الشورى",
    page: "388",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الزخرف",
    page: "394",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الدخان",
    page: "399",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الجاثية",
    page: "401",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الأحقاف",
    page: "404",
    url: "",
    level: "0",
    children: []
}, {
    caption: "محمد",
    page: "407",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الفتح",
    page: "410",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الحجرات",
    page: "414",
    url: "",
    level: "0",
    children: []
}, {
    caption: "ق",
    page: "416",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الذاريات",
    page: "419",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الطور",
    page: "421",
    url: "",
    level: "0",
    children: []
}, {
    caption: " النجم",
    page: "423",
    url: "",
    level: "0",
    children: []
}, {
    caption: "القمر",
    page: "425",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الرحمن",
    page: "428",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الواقعة",
    page: "430",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الحديد",
    page: "432",
    url: "",
    level: "0",
    children: []
}, {
    caption: "المجادلة",
    page: "436",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الحشر",
    page: "438",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الممتحنة",
    page: "441",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الصف",
    page: "443",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الجمعة",
    page: "444",
    url: "",
    level: "0",
    children: []
}, {
    caption: "المنافقون",
    page: "445",
    url: "",
    level: "0",
    children: []
}, {
    caption: "التغابن",
    page: "446",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الطلاق",
    page: "448",
    url: "",
    level: "0",
    children: []
}, {
    caption: "التحريم",
    page: "450",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الملك",
    page: "452",
    url: "",
    level: "0",
    children: []
}, {
    caption: "القلم",
    page: "453",
    url: "",
    level: "0",
    children: []
}, {
    caption: " الحاقة",
    page: "455",
    url: "",
    level: "0",
    children: []
}, {
    caption: "المعارج",
    page: "457",
    url: "",
    level: "0",
    children: []
}, {
    caption: "نوح",
    page: "458",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الجن",
    page: "460",
    url: "",
    level: "0",
    children: []
}, {
    caption: " المزمل",
    page: "461",
    url: "",
    level: "0",
    children: []
}, {
    caption: " المدثر",
    page: "462",
    url: "",
    level: "0",
    children: []
}, {
    caption: "القيامة",
    page: "464",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الإنسان",
    page: "465",
    url: "",
    level: "0",
    children: []
}, {
    caption: " المرسلات",
    page: "466",
    url: "",
    level: "0",
    children: []
}, {
    caption: "النبأ",
    page: "468",
    url: "",
    level: "0",
    children: []
}, {
    caption: "النازعات",
    page: "469",
    url: "",
    level: "0",
    children: []
}, {
    caption: "عبس",
    page: "470",
    url: "",
    level: "0",
    children: []
}, {
    caption: "التكوير",
    page: "471",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الانفطار",
    page: "472",
    url: "",
    level: "0",
    children: []
}, {
    caption: "المطففين",
    page: "472",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الانشقاق",
    page: "473",
    url: "",
    level: "0",
    children: []
}, {
    caption: "البروج",
    page: "474",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الطارق",
    page: "475",
    url: "",
    level: "0",
    children: []
}, {
    caption: " الأعلى",
    page: "476",
    url: "",
    level: "0",
    children: []
}, {
    caption: " الغاشية",
    page: "476",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الفجر",
    page: "477",
    url: "",
    level: "0",
    children: []
}, {
    caption: "البلد",
    page: "478",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الشمس",
    page: "478",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الليل",
    page: "479",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الضحى",
    page: "479",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الشرح",
    page: "480",
    url: "",
    level: "0",
    children: []
}, {
    caption: "التين",
    page: "480",
    url: "",
    level: "0",
    children: []
}, {
    caption: "العلق",
    page: "480",
    url: "",
    level: "0",
    children: []
}, {
    caption: "القدر",
    page: "481",
    url: "",
    level: "0",
    children: []
}, {
    caption: "البينة",
    page: "481",
    url: "",
    level: "0",
    children: []
}, {
    caption: " الزلزلة",
    page: "482",
    url: "",
    level: "0",
    children: []
}, {
    caption: "العاديات",
    page: "482",
    url: "",
    level: "0",
    children: []
}, {
    caption: "القارعة",
    page: "483",
    url: "",
    level: "0",
    children: []
}, {
    caption: "التكاثر",
    page: "483",
    url: "",
    level: "0",
    children: []
}, {
    caption: " العصر",
    page: "483",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الهمزة",
    page: "484",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الفيل",
    page: "484",
    url: "",
    level: "0",
    children: []
}, {
    caption: "قريش",
    page: "484",
    url: "",
    level: "0",
    children: []
}, {
    caption: " الماعون",
    page: "485",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الكوثر",
    page: "485",
    url: "",
    level: "0",
    children: []
}, {
    caption: " الكافرون",
    page: "485",
    url: "",
    level: "0",
    children: []
}, {
    caption: " النصر",
    page: "485",
    url: "",
    level: "0",
    children: []
}, {
    caption: "المسد",
    page: "486",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الإخلاص",
    page: "486",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الفلق",
    page: "486",
    url: "",
    level: "0",
    children: []
}, {
    caption: "الناس",
    page: "486",
    url: "",
    level: "0",
    children: []
}]
},
{
    caption: "فهرس الأجزاء\t",
    page: "2",
    url: "",
    level: "0",
    children: [{
    caption: "جزء-1 ",
    page: "3",
    url: "",
    level: "0",
    children: []
}, {
    caption:  "جزء-2 ",
    page: "20",
    url: "",
    level: "0",
    children: []
}, {
    caption:  "جزء-3 ",
    page: "36",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-4 ",
    page: "52",
    url: "",
    level: "0",
    children: []
}, {
   caption: "جزء-5 ",
    page: "68",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-6 ",
    page: "84",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-7 ",
    page: "100",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-8 ",
    page: "116",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-9 ",
    page: "132",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-10 ",
    page: "148",
    url: "",
    level: "0",
    children: []
}, {
   caption: "جزء-11 ",
    page: "164",
    url: "",
    level: "0",
    children: []
}, {
   caption: "جزء-12 ",
    page: "180",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-13 ",
    page: "196",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-14 ",
    page: "212",
    url: "",
    level: "0",
    children: []
}, {
   caption: "جزء-15 ",
    page: "228",
    url: "",
    level: "0",
    children: []
}, {
   caption: "جزء-16 ",
    page: "244",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-17 ",
    page: "260",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-18 ",
    page: "276",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-19 ",
    page: "292",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-20 ",
    page: "308",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-21 ",
    page: "324",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-22 ",
    page: "340",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-23 ",
    page: "356",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-24 ",
    page: "372",
    url: "",
    level: "0",
    children: []
}, {
   caption: "جزء-25 ",
    page: "388",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-26 ",
    page: "404",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-27 ",
    page: "420",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-28 ",
    page: "436",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-29 ",
    page: "452",
    url: "",
    level: "0",
    children: []
}, {
    caption: "جزء-30 ",
    page: "468",
    url: "",
    level: "0",
    children: []
}]
},
{
    caption: "فهرس الأحزاب\t",
    page: "2",
    url: "",
    level: "0",
    children: [{
    caption: "حزب 1 ",
    page: "3",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 2 ",
    page: "12",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 3 ",
    page: "20",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 4 ",
    page: "28",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 5 ",
    page: "36",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 6 ",
    page: "44",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 7 ",
    page: "52",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 8 ",
    page: "60",
    url: "",
    level: "0",
    children: []
}, {
     caption: "حزب 9 ",
    page: "68",
    url: "",
    level: "0",
    children: []
}, {
     caption: "حزب 10 ",
    page: "76",
    url: "",
    level: "0",
    children: []
}, {
  caption: "حزب 11 ",
    page: "84",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 12 ",
    page: "92",
    url: "",
    level: "0",
    children: []
}, {
  caption: "حزب 13 ",
    page: "100",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 14 ",
    page: "108",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 15 ",
    page: "116",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 16 ",
    page: "124",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 17 ",
    page: "132",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 18 ",
    page: "140",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 19 ",
    page: "148",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 20 ",
    page: "156",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 21 ",
    page: "164",
    url: "",
    level: "0",
    children: []
}, {
  caption: "حزب 22 ",
    page: "172",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 23 ",
    page: "180",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 24 ",
    page: "188",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 25 ",
    page: "196",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 26 ",
    page: "204",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 27 ",
    page: "212",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 28 ",
    page: "220",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 29 ",
    page: "228",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 30 ",
    page: "236",
    url: "",
    level: "0",
    children: []
}, {
     caption: "حزب 31 ",
    page: "244",
    url: "",
    level: "0",
    children: []
}, {
     caption: "حزب 32 ",
    page: "252",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 33 ",
    page: "260",
    url: "",
    level: "0",
    children: []
}, {
     caption: "حزب 34 ",
    page: "268",
    url: "",
    level: "0",
    children: []
}, {
     caption: "حزب 35 ",
    page: "276",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 36 ",
    page: "284",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 37 ",
    page: "292",
    url: "",
    level: "0",
    children: []
}, {
     caption: "حزب 38 ",
    page: "300",
    url: "",
    level: "0",
    children: []
}, {
     caption: "حزب 39 ",
    page: "308",
    url: "",
    level: "0",
    children: []
}, {
     caption: "حزب 40 ",
    page: "316",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 41 ",
    page: "324",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 42 ",
    page: "332",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 43 ",
    page: "340",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 44 ",
    page: "348",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 45 ",
    page: "356",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 46 ",
    page: "364",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 47 ",
    page: "372",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 48 ",
    page: "380",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 49 ",
    page: "388",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 50 ",
    page: "396",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 51 ",
    page: "404",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 52 ",
    page: "412",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 53 ",
    page: "420",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 54 ",
    page: "428",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 55 ",
    page: "436",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 56 ",
    page: "444",
    url: "",
    level: "0",
    children: []
}, {
   caption: "حزب 57 ",
    page: "452",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 58 ",
    page: "460",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 59 ",
    page: "468",
    url: "",
    level: "0",
    children: []
}, {
    caption: "حزب 60 ",
    page: "476",
    url: "",
    level: "0",
    children: []
}]
},
{caption:"سور وآيات فاضلة",page:"489",url:"",level:"1",children:[]},

{caption:"دعاء ختم القرآن",page:"487",url:"",level:"1",children:[]},

];